

# Update

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eid** | **String** |  |  [optional]
**col** | **String** |  |  [optional]
**val** | **String** |  |  [optional]



