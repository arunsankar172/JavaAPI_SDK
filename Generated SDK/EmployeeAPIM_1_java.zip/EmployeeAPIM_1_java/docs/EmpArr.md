

# EmpArr

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Employee&gt;**](Employee.md) |  |  [optional]



