

# Employee

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eid** | **String** |  |  [optional]
**ename** | **String** |  |  [optional]
**contact** | **String** |  |  [optional]
**email** | **String** |  |  [optional]
**salary** | **String** |  |  [optional]
**resume** | **String** |  |  [optional]



