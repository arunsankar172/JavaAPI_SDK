# DefaultApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPost**](DefaultApi.md#createPost) | **POST** /create | Add new Empoyee
[**deleteEidDelete**](DefaultApi.md#deleteEidDelete) | **DELETE** /delete/{eid} | Delete a Employees
[**downloadEidGet**](DefaultApi.md#downloadEidGet) | **GET** /download/{eid} | Download Employee Resume
[**listGet**](DefaultApi.md#listGet) | **GET** /list | List all Employees
[**updatePut**](DefaultApi.md#updatePut) | **PUT** /update | Update a employee
[**uploadEidPost**](DefaultApi.md#uploadEidPost) | **POST** /upload/{eid} | Upload Employee resume


<a name="createPost"></a>
# **createPost**
> Employee createPost(employee)

Add new Empoyee

Create new Employee

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.EmployeeAPIM.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    Employee employee = new Employee(); // Employee | New Employee
    try {
      Employee result = apiInstance.createPost(employee);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#createPost");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **employee** | [**Employee**](Employee.md)| New Employee | [optional]

### Return type

[**Employee**](Employee.md)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Insert success |  -  |
**419** | Invalid Email |  -  |
**420** | Invalid Phone number |  -  |

<a name="deleteEidDelete"></a>
# **deleteEidDelete**
> deleteEidDelete(eid)

Delete a Employees

Delete employee based on given Employee ID

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.EmployeeAPIM.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    Integer eid = 56; // Integer | 
    try {
      apiInstance.deleteEidDelete(eid);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#deleteEidDelete");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eid** | **Integer**|  |

### Return type

null (empty response body)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Delete Success |  -  |

<a name="downloadEidGet"></a>
# **downloadEidGet**
> downloadEidGet(eid)

Download Employee Resume

Download Employee Resume from database

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.EmployeeAPIM.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String eid = "eid_example"; // String | 
    try {
      apiInstance.downloadEidGet(eid);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#downloadEidGet");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eid** | **String**|  |

### Return type

null (empty response body)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Download Success |  -  |

<a name="listGet"></a>
# **listGet**
> EmpArr listGet()

List all Employees

List all employees in database

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.EmployeeAPIM.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    try {
      EmpArr result = apiInstance.listGet();
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#listGet");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**EmpArr**](EmpArr.md)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Data |  -  |

<a name="updatePut"></a>
# **updatePut**
> updatePut(update)

Update a employee

Updates employee depending on input parameter

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.EmployeeAPIM.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    Update update = new Update(); // Update | New Employee
    try {
      apiInstance.updatePut(update);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#updatePut");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **update** | [**Update**](Update.md)| New Employee | [optional]

### Return type

null (empty response body)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Updated Successfully |  -  |

<a name="uploadEidPost"></a>
# **uploadEidPost**
> uploadEidPost(eid, resume)

Upload Employee resume

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.EmployeeAPIM.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String eid = "eid_example"; // String | 
    File resume = new File("/path/to/file"); // File | 
    try {
      apiInstance.uploadEidPost(eid, resume);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#uploadEidPost");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eid** | **String**|  |
 **resume** | **File**|  | [optional]

### Return type

null (empty response body)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Upload Success |  -  |

