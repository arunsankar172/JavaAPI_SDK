

# InlineObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resume** | [**File**](File.md) |  |  [optional]



